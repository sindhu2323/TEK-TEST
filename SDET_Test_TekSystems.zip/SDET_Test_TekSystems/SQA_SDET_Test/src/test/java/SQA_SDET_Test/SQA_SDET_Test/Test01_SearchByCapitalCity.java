package SQA_SDET_Test.SQA_SDET_Test;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;

import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

public class Test01_SearchByCapitalCity {
	
	@Test
	void GetResponce () {
		// Given No param or headers or authentication (as it is not mandatory in this app) 
		//When fired API
		//then it should return the response
		
		given()
		.when()
			.get("https://restcountries.eu/rest/v2/capital/tallinn")
		.then()
			.log()
			.all();
		
	}
	
	
	@Test
	void GetStatusCode () {
		// Given No param or headers or authentication (as it is not mandatory in this app) 
				//When fired API
				//then the response code should be returned as 200 to check the success of the API
		
		given()
		.when()
			.get("https://restcountries.eu/rest/v2/capital/tallinn")
		.then()
			.statusCode(200);
		
	}
	
	@Test
	void GetCountryName() {
		// Given No param or headers or authentication (as it is not mandatory in this app) 
				//When fired API
				//then it should return correct Country name of the provided capital city in the response body
		
		given()
		.when()
			.get("https://restcountries.eu/rest/v2/capital/tallinn")
		.then()
			.body("name", hasItem("Estonia"))
			.body("capital", hasItem("Tallinn"));
		
	}
	
	@DataProvider(name = "DataForCapitalCities")
	public Object[][] dataForCapitalCities() {
			
//		Object[][] data = new Object[3][1];
//		
//		data[0][0] = "tallinn";
//		data[1][0] = "delhi";
//		data[2][0] = "washington";
//		data[3][0] = "rome";
//		
//		return data;
		
		return new Object [][] {
			{"tallinn"},
			{"delhi"},
			{"washington"},
			{"rome"}
		};
	}
	
	@Test (dataProvider = "DataForCapitalCities")
	void GetCountryNames(String capitalName) {
		// This is a data driven test using data provider
		// Given No param or headers or authentication (as it is not mandatory in this app) 
				//When fired API
				//then it should return correct Country name of the provided capital city in the response body in each iteration as per the capitals
		
		given()
		.when()
			.get("https://restcountries.eu/rest/v2/capital/" + capitalName)
		.then()
			.statusCode(200);
			
		
	}
	

}
